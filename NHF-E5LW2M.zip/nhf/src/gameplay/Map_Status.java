package gameplay;

/**
 * Map státuszok, ha egy olyan mapon vagyunk ahol már voltunk, vagy egy újban
 */
public enum Map_Status {IN_PREVIOUS, IN_NEW};
